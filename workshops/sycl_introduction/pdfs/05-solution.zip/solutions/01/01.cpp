#include <iostream>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

int main() {
  const size_t N = 4;
  const size_t M = 4;

  std::vector<float> input(N * M), output(N * M);

  for (size_t i = 0; i < N * M; ++i) {
    input[i] = static_cast<float>(i);
  }

  {
    queue q;
    buffer<float, 2> buf_input(input.data(), range<2>(N, M));
    buffer<float, 2> buf_output(output.data(), range<2>(M, N));

    q.submit([&](handler &cgh) {
      auto acc_input = buf_input.get_access<access::mode::read>(cgh);
      auto acc_output = buf_output.get_access<access::mode::write>(cgh);

      cgh.parallel_for(range<2>(N, M), [=](id<2> idx) {
        size_t row = idx[0];
        size_t col = idx[1];
        acc_output[col][row] = acc_input[row][col];
      });
    });

    // OPTIMIZED nd_range
    // q.submit([&](handler &cgh) {
    //   auto acc_input = buf_input.get_access<access::mode::read>(cgh);
    //   auto acc_output = buf_output.get_access<access::mode::write>(cgh);
    //
    //   cgh.parallel_for(nd_range<2>(range<2>(N, M), range<2>(2, 2)),
    //                    [=](nd_item<2> it) {
    //                      size_t row = it.get_global_id(0);
    //                      size_t col = it.get_global_id(1);
    //                      acc_output[col][row] = acc_input[row][col];
    //                    });
    // });
  }

  std::cout << "Output matrix:\n";
  for (size_t i = 0; i < N; ++i) {
    for (size_t j = 0; j < M; ++j) {
      std::cout << output[i * M + j] << " ";
    }
    std::cout << "\n";
  }

  return 0;
}
