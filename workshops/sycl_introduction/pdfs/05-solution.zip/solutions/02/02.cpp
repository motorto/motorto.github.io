#include <iostream>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

int main() {
  const size_t N = 4;

  std::vector<float> A(N * N, 1.0f), B(N * N, 2.0f), C(N * N, 0.0f);

  {
    queue q;
    buffer<float, 2> bufA(A.data(), range<2>(N, N));
    buffer<float, 2> bufB(B.data(), range<2>(N, N));
    buffer<float, 2> bufC(C.data(), range<2>(N, N));

    q.submit([&](handler &cgh) {
      auto accA = bufA.get_access<access::mode::read>(cgh);
      auto accB = bufB.get_access<access::mode::read>(cgh);
      auto accC = bufC.get_access<access::mode::write>(cgh);

      cgh.parallel_for(range<2>(N, N), [=](id<2> idx) {
        size_t row = idx[0];
        size_t col = idx[1];
        float sum = 0.0f;
        for (size_t k = 0; k < N; ++k) {
          sum += accA[row][k] * accB[k][col];
        }
        accC[row][col] = sum;
      });
    });

    // OPTIMIZED Using ND_RANGE

    // q.submit([&](handler &cgh) {
    //   auto accA = bufA.get_access<access::mode::read>(cgh);
    //   auto accB = bufB.get_access<access::mode::read>(cgh);
    //   auto accC = bufC.get_access<access::mode::write>(cgh);
    //
    //   range<2> global(N, N);
    //   range<2> local(2, 2);
    //
    //   cgh.parallel_for(nd_range<2>(global, local), [=](nd_item<2> it) {
    //     size_t row = it.get_global_id(0);
    //     size_t col = it.get_global_id(1);
    //     float sum = 0.0f;
    //     for (size_t k = 0; k < N; ++k) {
    //       sum += accA[row][k] * accB[k][col];
    //     }
    //     accC[row][col] = sum;
    //   });
    // });
  }

  std::cout << "Result matrix C:\n";
  for (size_t i = 0; i < N; ++i) {
    for (size_t j = 0; j < N; ++j) {
      std::cout << C[i * N + j] << " ";
    }
    std::cout << "\n";
  }

  return 0;
}
