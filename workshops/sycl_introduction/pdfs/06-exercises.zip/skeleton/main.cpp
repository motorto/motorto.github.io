#include <iostream>
#include <random>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

// Function to print the grid
// TODO: Implement this function to print a 2D grid of size NxN.
void print_grid(int *grid, int N) {
  // Loop through the rows and columns of the grid and print the values
}

// Function to initialize the grid with random 0s and 1s
// TODO: Implement this function to populate the grid with random values (0 or
// 1).
void initialize_random_grid(int *grid, int N) {
  // Use std::random_device and std::uniform_int_distribution to initialize the
  // grid.
}

int main() {
  constexpr int N = 16;               // Grid size
  constexpr int num_generations = 10; // Number of generations to simulate

  // Create a SYCL queue
  queue q;

  // TODO: Allocate Unified Shared Memory (USM) for `grid` and `next_grid`.
  // These will store the current and next generations of the grid.

#ifdef DEBUG
  // TODO: Allocate USM memory for `debug_neighbors` to store neighbor counts
#endif

  // TODO: Initialize the grid with random values
  // Call the `initialize_random_grid` function.

  // Print the initial grid
  std::cout << "Initial Grid:\n";
  // TODO: Call the `print_grid` function to display the initial state of the
  // grid.

  for (int gen = 0; gen < num_generations; ++gen) {
    // Launch the kernel to compute the next generation
    q.parallel_for(range<2>(N, N), [=](id<2> idx) {
      int x = idx[0];
      int y = idx[1];

      // TODO: Calculate the number of live neighbors for cell (x, y).
      int alive_neighbors = 0;

      // Use nested loops to check the 8 neighboring cells, wrapping around the
      // grid boundaries, use the math formula talked in the slides.

#ifdef DEBUG
      // TODO: Store the neighbor count in `debug_neighbors`.
#endif

      // TODO: Apply the rules of the Game of Life to determine the next state
      // of the cell. Rules:
      // 1. A live cell with fewer than 2 or more than 3 neighbors dies.
      // 2. A dead cell with exactly 3 neighbors becomes alive.
      // 3. Otherwise, the cell state remains the same.
    });

    q.wait();

#ifdef DEBUG
    // TODO: Print the neighbor counts for debugging purposes.
    std::cout << "Neighbor Counts:\n";
    // Call the `print_grid` function to display the neighbor counts.
#endif

    // TODO: Swap the grids to prepare for the next generation.
    // This can be done using std::swap(grid, next_grid) ;).

    // Print the grid
    std::cout << "Generation " << gen + 1 << ":\n";
    print_grid(grid, N);
  }

  // TODO: Free the USM memory allocated for `grid`, `next_grid`, and optionally
  // `debug_neighbors`.

  return 0;
}
