#include <iostream>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

int main() {
  const size_t N = 4; // Number of rows
  const size_t M = 4; // Number of columns

  // Initialize input matrix and output matrix
  std::vector<float> input(N * M, 0.0f);
  std::vector<float> output(N * M, 0.0f);

  // Fill the input matrix
  for (size_t i = 0; i < N * M; ++i) {
    input[i] = static_cast<float>(i);
  }

  {
    // Create a SYCL queue
    queue q;

    // Create SYCL buffers for input and output matrices
    buffer<float, 2> buf_input(input.data(), range<2>(N, M));
    buffer<float, 2> buf_output(output.data(), range<2>(M, N));

    // Submit kernel to compute the transpose
    q.submit([&](handler &cgh) {
      // TODO: Create accessors and a basic `parallel_for` to compute the
      // transpose
    });

    // Optional: Experiment with `nd_range`
  }

  // Print the transposed matrix
  std::cout << "Output Matrix (Transposed):" << std::endl;
  for (size_t i = 0; i < M; ++i) {
    for (size_t j = 0; j < N; ++j) {
      std::cout << output[i * N + j] << " ";
    }
    std::cout << std::endl;
  }

  return 0;
}
