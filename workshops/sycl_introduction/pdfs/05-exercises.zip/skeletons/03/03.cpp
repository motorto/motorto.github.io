#include <CL/sycl.hpp>
#include <oneapi/mkl.hpp>
#include <iostream>
#include <vector>
#include <chrono>

using namespace sycl;

constexpr size_t N = 256;

// Function to perform matrix multiplication using SYCL
void sycl_matrix_multiplication(queue &q, const std::vector<float> &A,
                                const std::vector<float> &B, std::vector<float> &C) {
    // TODO: Create SYCL buffers for matrices A, B, and C.

    q.submit([&](handler &cgh) {
        // TODO: Define accessors for the buffers.

        range<2> global_range{N, N};
        range<2> local_range{16, 16}; // try changing the local range
        nd_range<2> ndRange(global_range, local_range);

        cgh.parallel_for(ndRange, [=](nd_item<2> item) {
            // TODO: Implement the kernel logic to compute C[i, j] = sum(A[i, k] * B[k, j]).
        });
    }).wait();
}

// Function to perform matrix multiplication using oneAPI BLAS
void oneapi_blas_matrix_multiplication(queue &q, const std::vector<float> &A,
                                       const std::vector<float> &B, std::vector<float> &C) {
    // TODO: Create SYCL buffers for matrices A, B, and C.

    // TODO: Call the oneAPI BLAS gemm function for matrix multiplication.
    // https://oneapi-src.github.io/oneMKL/domains/blas/gemm.html
}

int main() {
    // Initialize SYCL queue
    queue q;

    // Initialize matrices
    std::vector<float> A(N * N, 2.0f); // Matrix A filled with 2s
    std::vector<float> B(N * N, 3.0f); // Matrix B filled with 3s
    std::vector<float> C_sycl(N * N, 0.0f); // Result matrix for SYCL
    std::vector<float> C_blas(N * N, 0.0f); // Result matrix for BLAS

    // SYCL Matrix Multiplication
    auto start_sycl = std::chrono::high_resolution_clock::now();
    sycl_matrix_multiplication(q, A, B, C_sycl);
    auto end_sycl = std::chrono::high_resolution_clock::now();

    // oneAPI BLAS Matrix Multiplication
    auto start_blas = std::chrono::high_resolution_clock::now();
    oneapi_blas_matrix_multiplication(q, A, B, C_blas);
    auto end_blas = std::chrono::high_resolution_clock::now();
    
    // Verify correctness
    bool correct = true;
    for (size_t i = 0; i < N * N; ++i) {
        if (std::abs(C_sycl[i] - C_blas[i]) > 1e-5) {
            correct = false;
            break;
        }
    }

    if (correct) {
        std::cout << "Results match!" << std::endl;
    } else {
        std::cout << "Results do not match!" << std::endl;
        return 1;
    }

    // Print performance comparison
    std::cout << "SYCL Time: "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end_sycl - start_sycl).count()
              << " ms" << std::endl;
    std::cout << "oneAPI BLAS Time: "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end_blas - start_blas).count()
              << " ms" << std::endl;

    

    return 0;
}

