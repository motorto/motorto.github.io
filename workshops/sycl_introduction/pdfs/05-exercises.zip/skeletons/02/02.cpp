#include <iostream>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

int main() {
  const size_t N = 4; // Size of the square matrix

  // Initialize matrices A, B, and C
  std::vector<float> A(N * N, 1.0f); // Fill with 1.0
  std::vector<float> B(N * N, 2.0f); // Fill with 2.0
  std::vector<float> C(N * N, 0.0f); // Output matrix

  {
    // Create a SYCL queue
    queue q;

    // Create SYCL buffers
    buffer<float, 2> bufA(A.data(), range<2>(N, N));
    buffer<float, 2> bufB(B.data(), range<2>(N, N));
    buffer<float, 2> bufC(C.data(), range<2>(N, N));

    // Submit kernel for naive matrix multiplication
    q.submit([&](handler &cgh) {
      // TODO: Create missing Accessors and  Implement naive matrix
      // multiplication
      auto accA = bufA.get_access<access::mode::read>(cgh);

      cgh.parallel_for(range<2>(N, N), [=](id<2> idx) {
        // Compute element C[row, col] by summing A[row, k] * B[k, col]
      });
    });

    // TODO: Implement an optimized version using `nd_range` and shared memory
    // locality
    // Optional: Experiment with different work-group sizes
  }

  // Print the result matrix C
  std::cout << "Result Matrix C:" << std::endl;
  for (size_t i = 0; i < N; ++i) {
    for (size_t j = 0; j < N; ++j) {
      std::cout << C[i * N + j] << " ";
    }
    std::cout << std::endl;
  }

  return 0;
}
