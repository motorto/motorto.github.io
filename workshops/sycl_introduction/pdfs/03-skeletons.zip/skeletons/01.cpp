#include <iostream>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

int main() {
  const int N = 1024;
  std::vector<int> data(N);

  buffer<int, 1> buf(data.data(), range<1>(N));
  queue q;

  q.submit([&](handler &cgh) {
     auto aA = buf.get_access<access::mode::write>(cgh);

     // TODO: Kernel goes here => aA[i]=id
   }).wait();

  host_accessor h_acc(buf);
  for (int i = 0; i < N; ++i) {
    std::cout << h_acc[i] << " ";
  }
  std::cout << std::endl;

  return 0;
}
