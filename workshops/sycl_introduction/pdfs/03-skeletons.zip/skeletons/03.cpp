#include <iostream>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

int main() {
  const int N = 256;
  std::vector<int> data(N, 0.0);
  std::vector<int> data_old(N, 0.0);
  for (int i = 0; i < N; ++i)
    data[i] = i;

  buffer<int, 1> buf(data.data(), range<1>(N));
  buffer<int, 1> buf_copy(data_old.data(), range<1>(N));
  queue q;

  q.submit([&](handler &cgh) {
    auto aA = buf.get_access(cgh);
    // TODO: kernel increment one here we access using aA
  });

  q.submit([&](handler &cgh) {
    auto aB = buf.get_access(cgh);
    auto aC = buf_copy.get_access(cgh);
    // TODO: kernel that copies from buffer aB to buffer aC
  });

  q.submit([&](handler &cgh) {
    auto aD = buf.get_access(cgh);
    // TODO: kernel that fills buffer aD to 42
  });

  // how can we force the last action to be completed before printing ?

  host_accessor h_acc(buf);
  host_accessor h_acc_copy(buf_copy);
  std::cout << "Original buffer after operations: ";
  for (int i = 0; i < N; ++i) {
    std::cout << h_acc[i] << " ";
  }
  std::cout << std::endl;

  std::cout << "Copied buffer: ";
  for (int i = 0; i < N; ++i) {
    std::cout << h_acc_copy[i] << " ";
  }
  std::cout << std::endl;

  return 0;
}
