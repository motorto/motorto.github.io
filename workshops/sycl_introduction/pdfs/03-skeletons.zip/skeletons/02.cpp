// Fill in the code parts (____)
#include <iostream>
#include <random>
#include <sycl/sycl.hpp>
#include <vector>

using namespace sycl;

class ____ {
public:
  void ____()(id<1> i, accessor<int, 1, access::mode::read_write> a) const {
    a[i] = ____;
  }
};

int main() {
  const int N = 512;
  std::vector<int> data(N);
  std::mt19937 gen;
  std::uniform_int_distribution<int> dis(1, 100);
  for (int i = 0; i < N; ++i)
    data[i] = dis(gen);

  buffer<int, 1> buf(data.data(), range<1>(N));
  queue q;

  q.submit([&](handler &cgh) {
     auto aA = buf.get_access<access::mode::read_write>(cgh);
     cgh.parallel_for<____>(range<1>(N), [=](id<1> i) {
       ____()(____, ____); // Que argumentos passamos ?? (acedemos ao vector
                           // atraves do aA);
     });
   }).wait();

  host_accessor h_acc(buf);
  for (int i = 0; i < N; ++i) {
    std::cout << h_acc[i] << " ";
  }
  std::cout << std::endl;

  return 0;
}
