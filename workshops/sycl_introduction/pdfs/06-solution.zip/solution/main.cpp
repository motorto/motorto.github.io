#include <sycl/sycl.hpp>
#include <iostream>
#include <random>
#include <vector>

using namespace sycl;

// Function to print the grid
void print_grid(int *grid, int N) {
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < N; ++j) {
      std::cout << grid[i * N + j] << " ";
    }
    std::cout << "\n";
  }
  std::cout << "\n";
}

// Function to initialize the grid with random 0s and 1s
void initialize_random_grid(int *grid, int N) {
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<> dist(0, 1);

  for (int i = 0; i < N * N; ++i) {
    grid[i] = dist(gen); // Randomly assign 0 or 1
  }
}

int main() {
  constexpr int N = 16;               // Grid size
  constexpr int num_generations = 10; // Number of generations

  // Create a SYCL queue
  queue q;

  // Allocate Unified Shared Memory (USM) for the grids
  int *grid = malloc_shared<int>(N * N, q);
  int *next_grid = malloc_shared<int>(N * N, q);

#ifdef DEBUG
  int *debug_neighbors =
      malloc_shared<int>(N * N, q); // To store neighbor counts
#endif

  // Initialize the grid with random values
  initialize_random_grid(grid, N);

  // Print the initial grid
  std::cout << "Initial Grid:\n";
  print_grid(grid, N);

  for (int gen = 0; gen < num_generations; ++gen) {
    // Launch the kernel to compute the next generation
    q.parallel_for(range<2>(N, N), [=](id<2> idx) {
      int x = idx[0];
      int y = idx[1];

      int alive_neighbors = 0;

      // Check all 8 neighbors
      for (int dx = -1; dx <= 1; ++dx) {
        for (int dy = -1; dy <= 1; ++dy) {
          if (dx == 0 && dy == 0)
            continue;                // Skip self
          int nx = (x + dx + N) % N; // Wrap boundary
          int ny = (y + dy + N) % N; // Wrap boundary
          alive_neighbors += grid[nx * N + ny];
        }
      }

#ifdef DEBUG
      // Store the neighbor count for debugging
      debug_neighbors[x * N + y] = alive_neighbors;
#endif

      // Apply Game of Life rules
      int current = grid[x * N + y];
      if (current == 1 && (alive_neighbors < 2 || alive_neighbors > 3)) {
        next_grid[x * N + y] = 0; // Cell dies
      } else if (current == 0 && alive_neighbors == 3) {
        next_grid[x * N + y] = 1; // Cell becomes alive
      } else {
        next_grid[x * N + y] = current; // Cell state remains
      }
    });

    // Wait for the kernel to complete
    q.wait();

#ifdef DEBUG
    // Print the debug information
    std::cout << "Neighbor Counts:\n";
    print_grid(debug_neighbors, N);
#endif

    // Swap the grids
    std::swap(grid, next_grid);

    // Print the grid
    std::cout << "Generation " << gen + 1 << ":\n";
    print_grid(grid, N);
  }

  // Free USM memory
  free(grid, q);
  free(next_grid, q);
#ifdef DEBUG
  free(debug_neighbors, q);
#endif

  return 0;
}
